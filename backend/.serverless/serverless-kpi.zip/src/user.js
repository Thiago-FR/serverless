import { prismaClientDB } from "./db.js"

export const findAll = async (e) => {
    const result = await prismaClientDB.user.findMany();

    return {
        statusCode: 200,
        body: JSON.stringify(result)
    };
}

export const create = async (e) => {
    const { name, username } = JSON.parse(e.body);

    const result = await prismaClientDB.user.create({
        data: {
            name, username
        }
    });

    return {
        statusCode: 200,
        body: JSON.stringify(result)
    };
}
