import { PrismaClient } from "@prisma/client";

const prismaClientDB = new PrismaClient();

export { prismaClientDB };